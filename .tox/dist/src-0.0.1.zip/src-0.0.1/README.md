**create env
conda create -n wineq python 3.8.3 -y

**activate environment
conda activate wineq

**created requirements.txt file
**installed the requirements
pip install -r requirements.txt

**create a python file which will create templates for you

**download the dataset

git init

dvc init

dvc add data_given/winequality.csv

git add .

git commit -m "first commit"

git add . && git commit -m "update Readme.md"

git remote add origin https://github.com/kritikawin/winequality.git

git branch -M main

git push origin main

**tox command

tox

**for rebuilding

tox -r 

**pytest command

pytest -v

**setup commands

pip install -e .

** build your own package commands

python setup.py sdist bdist_wheel



